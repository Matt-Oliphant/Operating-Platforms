// package projectOne;
package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author coce@snhu.edu
 */
public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nAbout to test the singleton...");
		
		/* 
		 * Trying to instantiate: GameService service = new GameService();
		 * will lead to an error. The GameService constructor is designed to only allow one instance
		 */ 
		GameService service = GameService.getInstance();
		
		/* A simple for loop to print the games */
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}
	} /* End testSingleton method */
	
} /* End SingletonTester Class */
