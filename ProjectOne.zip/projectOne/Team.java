// package projectOne;
package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a team
 * 
 * <p>
 * Notice the constructor requires an id and name to be passed when creating. Also note that
 * no mutators (setters) are defined so these values cannot be changed once a team is created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	
	/**
	 * Removed the team id and name variables and added an ArrayList of players
	 */
	List<Player> players = new ArrayList<Player>();
	
	/**
	 * Constructor gets passed an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
		this.id = id;
		this.name = name;
	}

	/**
	 * Adds the player to the team (list of players)
	 * @return the Player added
	 */
	public Player addPlayer(String name) {

		/* A local player instance */
		Player player = null;

		/**
		 * Iterator will check if a player already exists in the list or not
		 * If not, the player will be added to the list
		 * If so, the player will be returned and user will be informed they need to pick a unique name
		 */
		Iterator<Player> playerIterator = players.iterator();
		while (playerIterator.hasNext()) {
			Player playerToCompare = (Player)playerIterator.next();
			if (playerToCompare.getName().equals(name)) {
				player = playerToCompare;
				System.out.println("Player already exists... Player names must be unique- Try again.");
			}
		}

		/* If not found, make a new player instance and add to list of games */
		if (player == null) {
			player = new Player(GameService.getInstance().getNextPlayerId(), name);
			players.add(player);
		}

		/* Return the new/ existing player instance to the caller */
		return player;
	} /* End addPlayer method */

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	} /* End toString method */
	
} /* End Team Class */