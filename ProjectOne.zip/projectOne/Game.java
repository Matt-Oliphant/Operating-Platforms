// package projectOne;
package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the constructor requires an id and name to be passed when creating. Also note that
 * no mutators (setters) are defined, so these values cannot be changed once a game is created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	
	/**
	 * Removed the id and name variables and added a list of teams (private by default)
	 */
	List<Team> teams = new ArrayList<Team>();

	/**
	 * Removed private constructor
	 * Constructor is passed an identifier and name
	 */
	public Game(long id, String name) {
		super(id, name);
		this.id = id;
		this.name = name;
	}

	/**
	 * Adds teams to the game
	 * @return the current Team
	 */
	public Team addTeam(String name) {

		/* A local team instance */
		Team team = null;

		/*
		 * Iterator will check if a team already exists in the list or not
		 * If not, the team will be added to the list
		 * If so, the team will be returned and user will be informed they need to pick a new name
		 */
		Iterator<Team> teamsIterator = teams.iterator();
		while (teamsIterator.hasNext()) {
			Team teamToCompare = (Team)teamsIterator.next();
			if (teamToCompare.getName().equals(name)) {
				team = teamToCompare;
				System.out.println("Team already exists... Team names must be unique- Try again.");
			}
		}

		/* If not found, make a new team instance and add to list of teams */
		if (team == null) {
			team = new Team(GameService.getInstance().getNextTeamId(), name);
			teams.add(team);
		}

		/* Return the new/ existing team instance to the caller */
		return team;
	} /* End addTeam method */
	
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	} /* End toString method */
	
} /* End Game Class */