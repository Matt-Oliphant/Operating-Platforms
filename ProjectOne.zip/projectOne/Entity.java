// package projectOne;
package com.gamingroom;

/**
 * A super class to Player, Team, or Game subclasses
 * Created the base class for an Entity which can either be a Player, Team, or Game 
 * 
 * @author coce@snhu.edu
 */
public class Entity {
	long id;
	String name;
	
	@SuppressWarnings("unused") /* Removes ability to create default object */
	private Entity() {
	} 
	
	/**
	 * Constructor used to make an Entity instance, either player, team or game
	 * @param id
	 * @param name
	 */
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	/**
	 * Accessors for the Entity's id and/ or name
	 * @return id or name
	 */
	public long getId() {
		return this.id;
	} /* End getId method */
	
	public String getName() {
		return this.name;
	} /* End getName method */

	@ Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";	
	} /* End toString method */
	
} /* End Entity Class */
