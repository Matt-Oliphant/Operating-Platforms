// package projectOne;
package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game, player, and team identifiers
	 */
	private static long nextGameId = 0;
	private static long nextPlayerId = 0;
	private static long nextTeamId = 0;

	/*
	 * The purpose of the Singleton pattern is so only one object can be instantiated
	 * Default (null) gameService is static so the ProgramDriver can access it
	 * Making the constructor private allows for a single instantiation
	 * The getGameService method instantiates the first gameService or returns the first gameService
	 */
	private static GameService gameService;
	
	private GameService() {
	}
	
	/**
	 * Add getter that returns this instance of the game service
	 * @return the game service instance (new or existing)
	 */
	public static GameService getInstance() {
		if (gameService == null) {
			gameService = new GameService();
		}
		return gameService;
	} /* End getInstance method */
	
	/**
	 * Add game adds a game to our list of games
	 * @param name
	 * @return current game
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		/*
		 * In this case:
		 * The purpose of the iterator pattern is to easily check a list for the name of each game
		 * The iterator index's each game in the list and compares it's name to the name parameter
		 * If the name is found the indexed game is returned, else a new game is added to the list
		 */
		Iterator<Game> gameIterator = games.iterator();
		while (gameIterator.hasNext()) {
			Game gameToCompare = (Game)gameIterator.next();
			if (gameToCompare.getName().equals(name)) {
				game = gameToCompare;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	} /* End addGame method */
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		/*
		 * In this case:
		 * The purpose of the iterator pattern is to easily check a list for the id of each game
		 * The iterator index's each game in the list and compares it's id to the id parameter
		 * If the id is found the indexed game is returned (else null is returned)
		 */
		// if found, simply assign that instance to the local variable
		Iterator<Game> idIterator = games.iterator();
		while (idIterator.hasNext()) {
			Game gameToCompare = (Game)idIterator.next();
			if (gameToCompare.getId() == id) {
				game = gameToCompare;
			}
		}

		return game;
	} /* End getGame (id) method */

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		/*
		 * In this case:
		 * The purpose of the iterator pattern is to easily check a list for the name of each game
		 * The iterator index's each game in the list and compares it's name to the name parameter
		 * If the name is found the indexed game is returned (else null is returned)
		 */
		// if found, simply assign that instance to the local variable
		Iterator<Game> nameIterator = games.iterator();
		while (nameIterator.hasNext()) {
			Game gameToCompare = (Game)nameIterator.next();
			if (gameToCompare.getName().equals(name)) {
				game = gameToCompare;
			}
		}

		return game;
	} /* End getGame (name) method */

	/**
	 * Returns the number of games currently active
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	} /* End getGameCount method */
	
	/**
	 * Method increases the player id by one
	 * @return next player's id
	 */
	public long getNextPlayerId() {
		return nextPlayerId++;
	} /* End getNextPlayerId method */
	
	/**
	 * Method increases the team id by one
	 * @return next team's id
	 */
	public long getNextTeamId() {
		return nextTeamId++;
	} /* End getNextTeamId method */
	
} /* End GameService Class */